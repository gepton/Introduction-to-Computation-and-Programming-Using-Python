# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 19:17:20 2024

@author: gan
"""

# Finger exercise: Modify the code in Figure 20-5 so that it produces
# the plot in Figure 20-8.

import numpy as np
import matplotlib.pyplot as plt


def get_data(input_file):
    with open(input_file, 'r') as data_file:
        distances = []
        masses = []
        data_file.readline() #ignore header
        for line in data_file:
            d, m = line.split(',')
            distances.append(float(d))
            masses.append(float(m))
    return (masses, distances)



def fit_data(input_file):
    masses, distances = get_data(input_file)
    distances = np.array(distances)
    forces = np.array(masses)*9.81
    plt.plot(forces, distances, 'ko',
               label = 'Measured displacements')
    plt.title('Measured Displacement of Spring')
    plt.xlabel('|Force| (Newtons)')
    plt.ylabel('Distance (meters)')
    #find linear fit
    a,b = np.polyfit(forces, distances, 1)
    predicted_distances = a*np.array(forces) + b
    k = 1.0/a #see explanation in text
    plt.plot(forces, predicted_distances,
             label = 'Linear fit, k = ' + str(round(k, 5)))
    
    #find cubic fit
    force_1_5kg = 1.5 * 9.81
    fit = np.polyfit(forces, distances, 3)
    
    #predict the values for distances
    predicted_distances_cubic = np.polyval(fit, forces)
    
    #predict the value for distance, for 1.5 kg
    predicted_distance_1_5kg = np.polyval(fit, force_1_5kg)
    
    #Add the extra value (for 1.5 kg) to the "predicted_distances_cubic" array
    predicted_distances_cubic = np.append(predicted_distances_cubic, predicted_distance_1_5kg)
     
    #Add the extra value (for 1.5 kg) to the "forces" array
    forces = np.append(forces, force_1_5kg)
    
    plt.plot(forces, predicted_distances_cubic, 'k:', label='cubic fit')

    plt.legend(loc = 'best')

fit_data('springData.csv')


