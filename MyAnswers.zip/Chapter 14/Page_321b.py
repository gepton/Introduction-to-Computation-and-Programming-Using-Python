

# -*- coding: utf-8 -*-
"""
Created on Wed Nov 15 19:36:13 2023

@author: gan
"""

# =============================================================================
# Finger exercise: Modify the DFS algorithm to find a path that
# minimizes the sum of the weights. Assume that all weights are
# positive integers.
# =============================================================================


# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


class Node(object):
    def __init__(self, name):
        """Assumes name is a string"""
        self._name = name
    def get_name(self):
        return self._name
    def __str__(self):
        return self._name

class Edge(object):
    def __init__(self, src, dest):
        """Assumes src and dest are nodes"""
        self._src = src
        self._dest = dest
    def get_source(self):
        return self._src
    def get_destination(self):
        return self._dest
    def __str__(self):
        return self._src.get_name() + '->' + self._dest.get_name()

class Weighted_edge(Edge):
    def __init__(self, src, dest, weight):
        """Assumes src and dest are nodes, weight a number"""
        self._src = src
        self._dest = dest
        self._weight = weight
    def get_weight(self):
        return self._weight
    def __str__(self):
        return (f'{self._src.get_name()}->({self._weight})' +
               f'{self._dest.get_name()}')
    
##########################################
    
class Digraph(object):
    #nodes is a list of the nodes in the graph
    #edges is a dict mapping each node to a list of its children
    def __init__(self):
        self._nodes = []
        self._edges = {}
        self._weight = {}
    def add_node(self, node):
        if node in self._nodes:
            raise ValueError('Duplicate node')
        else:
            self._nodes.append(node)
            self._edges[node] = []
    def add_edge(self, Weighted_edge):
        src = Weighted_edge.get_source()
        dest = Weighted_edge.get_destination()
        weight = Weighted_edge.get_weight()
        if not (src in self._nodes and dest in self._nodes):
            raise ValueError('Node not in graph')
        self._edges[src].append(dest)
        
        # enter the key (as a tuple of 2 nodes) and assign the value of weight
        self._weight[str(src.get_name()),str(dest.get_name())] = weight
        #self._weight = weight
      
        # Add funct to retrieve the weight
        # !!! In order to call this funct, we must enter src & dest as strings
# =============================================================================
#     def get_weight(self, src, dest):
#         return self._weight[src, dest]
# =============================================================================

    def get_weight(self, src, dest):
        if (src, dest) in self._weight:
            return self._weight[src, dest]
        else:
            return 0
    
    def get_weight_test(self):
        return self._weight
       
    
    def children_of(self, node):
        return self._edges[node]
    def has_node(self, node):
        return node in self._nodes
    def __str__(self):
        result = ''
        for src in self._nodes:
            for dest in self._edges[src]:
                result = (result + src.get_name() + '->'
                         + dest.get_name() + '\n')
        return result[:-1] #omit final newline
    

 

##############################################################

class Graph(Digraph):
    def add_edge(self, edge):
        Digraph.add_edge(self, edge)
        rev = Edge(edge.get_destination(), edge.get_source())
        Digraph.add_edge(self, rev)
        
###########################################################        
   
def print_path(path):
    """Assumes path is a list of nodes"""
    result = ''
    for i in range(len(path)):
        result = result + str(path[i])
        if i != len(path) - 1:
            result = result + '->'
    return result 




def DFS(graph, start, end, path, current_weight, to_print=False):
    path = path + [start]

    if to_print:
        print('Current DFS path:', print_path(path), 'total weight:', current_weight)


    if start == end:

        # Add every path in the global dictionary with "current_weight" as the key
        empty_dict1[current_weight] = print_path(path) 

    for node in graph.children_of(start):
        if node not in path:
            # Calculate the weight of the edge from start to node
            edge_weight = graph.get_weight(str(start), str(node))
            new_weight = current_weight + edge_weight
            new_path = DFS(graph, node, end, path[:], new_weight, to_print)  # Pass copies of shortest and path


def shortest_path(graph, start, end, to_print = False):
    """Assumes graph is a Digraph; start and end are nodes
       Returns a shortest path from start to end in graph"""
    return DFS(graph, start, end, [], 0, to_print)


def test_SP():
    nodes = []
    for name in range(6): #Create 6 nodes
        nodes.append(Node(str(name)))
    g = Digraph()
    for n in nodes:
        g.add_node(n)

# Initialization for graph
    g.add_edge(Weighted_edge(nodes[0],nodes[1],3))
    g.add_edge(Weighted_edge(nodes[1],nodes[2],4))
    g.add_edge(Weighted_edge(nodes[2],nodes[3],5))
    g.add_edge(Weighted_edge(nodes[3],nodes[4],6))
    g.add_edge(Weighted_edge(nodes[2],nodes[4],5))
    g.add_edge(Weighted_edge(nodes[1],nodes[3],1))


# =============================================================================
# #Initialization for graph_2
#     g.add_edge(Weighted_edge(nodes[0],nodes[1],10))
#     g.add_edge(Weighted_edge(nodes[1],nodes[2],20))
#     g.add_edge(Weighted_edge(nodes[2],nodes[3],30))
#     g.add_edge(Weighted_edge(nodes[3],nodes[4],10))
#     g.add_edge(Weighted_edge(nodes[3],nodes[5],30))
#     g.add_edge(Weighted_edge(nodes[4],nodes[5],10))
#     g.add_edge(Weighted_edge(nodes[2],nodes[5],10))
# =============================================================================

#for graph_2 nodes[4] should change to ---->   nodes[5]
    sp = shortest_path(g, nodes[0], nodes[4], to_print = True)
    min_key = min(empty_dict1.keys()) 
    print('the minimum distance is : ', min_key, 'for the path : ', empty_dict1[min_key])

empty_dict1 = {}
    
test_SP()