# -*- coding: utf-8 -*-
"""
Created on Wed Aug  9 19:49:29 2023

@author: gan
"""

x = int(input('Enter an integer greater than 2:  '))
highest_divisor = None

for guess in range (2, x):
    if x%guess == 0:
        highest_divisor = guess

if highest_divisor != None:
    print('Highest Divisor of', x, 'is', highest_divisor)
else:
    print(x, 'is a prime number')
    
    
    
# Finger exercise: Write a program that asks the user to enter an
# integer and prints two integers, root and pwr, such that 1 < pwr < 6
# and root**pwr is equal to the integer entered by the user. If no such
# pair of integers exists, it should print a message to that effect.

x = int(input('Enter an integer number:  '  ))

root  = None
pwr  = None
base = 0

while base < x and root == None and pwr == None:
    for i in range(2,6):
        if base**i == x:
            root = base
            pwr = i
    base = base + 1
    
if root != None and pwr != None:
   print('root is: ', root, ' pwr is: ', pwr)
else: 
   print('no such pair of integers exists')