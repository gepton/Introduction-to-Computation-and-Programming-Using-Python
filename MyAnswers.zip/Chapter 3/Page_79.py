# -*- coding: utf-8 -*-
"""
Created on Mon Aug 28 19:32:07 2023

@author: gan
"""
# Finger exercise: What would have to be changed to make the code
# in Figure 3-5 work for finding an approximation to the cube root of
# both negative and positive numbers? Hint: think about changing low
# to ensure that the answer lies within the region being searched.

x = 3375 # A test case for code in Figure 3-5
# # Figure 3-5
epsilon = 0.01
num_guesses, low = 0, 0

if x > 0:
    high = max(1, x)
else:
    low = x
    high = max(x, 0)   
#high = max(1, x)
ans = (high + low)/2
while abs(ans**3 - x) >= epsilon:
    print('low =', low, 'high =', high, 'ans =', ans)
    num_guesses += 1
    if ans**3 < x:
       low = ans
    else:
        high = ans
    ans = (high + low)/2
print('number of guesses =', num_guesses)
print(ans, 'is close to cube root of', x)



# Finger exercise: The Empire State Building is 102 stories high. A
# man wanted to know the highest floor from which he could drop an
# egg without the egg breaking. He proposed to drop an egg from the
# top floor. If it broke, he would go down a floor, and try it again. He
# would do this until the egg did not break. At worst, this method
# requires 102 eggs. Implement a method that at worst uses seven
# eggs.

x = 102
num_guesses, low = 0, 0
high = max(1, x)

ans = (high + low)/2
while num_guesses < 7:
    quest = input("Did the egg break? in {}:  ".format(ans))
    if quest == 'yes':
        high = ans
    else:
        low = ans
    ans = (high + low)/2
    num_guesses += 1
print('egg would break if drop from higher than floor', ans)    
print(num_guesses)













