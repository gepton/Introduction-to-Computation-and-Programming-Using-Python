# -*- coding: utf-8 -*-
"""
Created on Tue Aug 29 19:09:16 2023

@author: gan
"""

x = 144 # bisection code implementation
# Figure 3-5
epsilon = 0.01
num_guesses, low = 0, 0
high = max(1, x)
ans = (high + low)/2
while abs(ans**2 - x) >= epsilon:
    print('low =', low, 'high =', high, 'ans =', ans)
    num_guesses += 1
    if ans**2 < x:
        low = ans
    else:
        high = ans
    ans = (high + low)/2
print('number of guesses =', num_guesses)
print(ans, 'is close to square root of', x)





k = 144 # Test case for Figure 3-7
# Figure 3-7
#Newton-Raphson for square root
#Find x such that x**2 - 24 is within epsilon of 0
epsilon = 0.01
guess = k/2
num_guesses = 0
while abs(guess**2 - k) >= epsilon:
    guess = guess - (((guess**2) - k)/(2*guess))
    num_guesses += 1
print('Square root of', k, 'is about', guess)
print('number of guesses =', num_guesses)