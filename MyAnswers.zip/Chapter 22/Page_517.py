# -*- coding: utf-8 -*-
"""
Created on Tue May 28 19:22:12 2024

@author: gan
"""

# Finger exercise: It is sometimes illuminating to plot things relative
# to a baseline, as seen in Figure 22-4. Modify plot_housing to produce
# such plots. The bars below the baseline should be in red. Hint: use
# the bottom keyword argument to plt.bar.

import numpy as np
import matplotlib.pyplot as plt

def plot_housing(impression, baseline=200):
  """Assumes impression a str. Must be one of 'flat',
       'volatile,' and 'fair'
  Produce bar chart of housing prices relative to a baseline, 
  coloring bars below baseline red"""
  labels, prices = [], []
  with open('midWestHousingPrices.csv', 'r') as f:
    #Each line of file contains year quarter price
    #for Midwest region of U.S.
    for line in f:
      year, quarter, price = line.split(',')
      label = year[2:4] + '\n Q' + quarter[1]
      labels.append(label)
      prices.append(int(price)/1000)
  quarters = np.arange(len(labels)) #x coords of bars
  width = 0.8 #Width of bars

  # Set colors based on price relative to baseline
  colors = ['red' if price < baseline else 'blue' for price in prices]

  plt.bar(quarters, prices, width, color=colors, bottom=baseline)
  plt.xticks(quarters+width/2, labels)
  plt.title('Housing Prices in U.S. Midwest (Relative to Baseline)')
  plt.xlabel('Quarter')
  plt.ylabel('Average Price ($1,000\'s)')
  
  # Set y-axis limits based on impression (adjusted for baseline)
  if impression == 'flat':
    plt.ylim(baseline-50, baseline+50)
  elif impression == 'volatile':
    plt.ylim(baseline-40, baseline+40)
  elif impression == 'fair':
    plt.ylim(baseline-25, baseline+25)
  else:
    raise ValueError

# Example usage with baseline set to 200 (default)
plot_housing('fair')

# You can adjust the baseline value as needed
# plot_housing('fair', baseline=180)
