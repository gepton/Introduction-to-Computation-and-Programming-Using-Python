# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 19:39:32 2024

@author: gan
"""

# =============================================================================
# Finger exercise: Write an expression that evaluates to True if
# Phoenix was warmer than Tampa on October 31, 2000, and False
# otherwise.
# =============================================================================

import pandas as pd


pd.set_option('display.max_rows', 6)
pd.set_option('display.max_columns', 5)
temperatures = pd.read_csv('US_temperatures.csv')

new_dataset = temperatures.loc[temperatures['Date']==20001031][['Phoenix','Tampa']]
print(new_dataset['Phoenix'] > new_dataset['Tampa'])

