# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 19:14:42 2024

@author: gan
"""

# =============================================================================
# Finger exercise: Write an expression that returns a DataFrame
# containing games in which the USA but not France played.
# =============================================================================

# =============================================================================
# In test.csv I added the below 2 rows, at the bottom
# Championship,Sweden,2,USA,0
# Championship,France,2,USA,0
# =============================================================================

import pandas as pd
wwc = pd.read_csv('test.csv')

print(wwc.loc[((wwc['Winner'] == 'USA') & (wwc['Loser'] != 'France')) | ((wwc['Winner'] != 'France') & (wwc['Loser'] == 'USA'))])