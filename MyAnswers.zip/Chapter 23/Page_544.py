# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 19:48:54 2024

@author: gan
"""

# =============================================================================
# Finger exercise: Write a function that returns the sum of the goals
# scored by winners.
# =============================================================================


import pandas as pd
wwc = pd.read_csv('wwc2019_q-f.csv')

rounds = ['Semis', 'Semis', '3rd Place', 'Championship']
teams = ['USA', 'Netherlands', 'Sweden', 'USA']
df = pd.DataFrame({'Round': rounds, 'Winner': teams})

df['W Goals'] = [2, 1, 2,2]

quarters_dict = {'Round': ['Quarters']*4,
'Winner': ['England', 'USA', 'Netherlands', 'Sweden'], 'W Goals': [3, 2, 2, 2]}
df = pd.concat([pd.DataFrame(quarters_dict), df], sort = True)

tot_goals = 0
for w in df['W Goals']:
    tot_goals += w
print('Total Goals: ', tot_goals)