# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 19:10:56 2024

@author: gan
"""

# =============================================================================
# Finger exercise: Print a DataFrame containing only the games in
# which Sweden played either Germany or Netherlands.
# =============================================================================


import pandas as pd
wwc = pd.read_csv('wwc2019_q-f.csv')


def get_games(df, countries):
    return df[(df['Winner'].isin(countries)) | (df['Loser'].isin(countries))]

print(get_games(get_games(wwc, ['Sweden']), ['Germany', 'Netherlands']))
