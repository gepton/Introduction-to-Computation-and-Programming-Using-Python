# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 19:36:02 2024

@author: gan
"""

# =============================================================================
# Finger exercise: Write an expression that selects all even
# numbered rows in wwc.
# =============================================================================

import pandas as pd
wwc = pd.read_csv('wwc2019_q-f.csv')

print(wwc.loc[2::2])