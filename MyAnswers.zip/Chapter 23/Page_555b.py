# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 19:34:34 2024

@author: gan
"""

# =============================================================================
# Finger exercise: Write code to extract the date on which the
# temperature in Phoenix was 41.4C
# =============================================================================

import pandas as pd

temperatures = pd.read_csv('US_temperatures.csv')

Date = temperatures.loc[temperatures['Phoenix']==41.4]['Date'].values
print(Date)


