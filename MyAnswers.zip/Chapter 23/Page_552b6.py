# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 19:17:16 2024

@author: gan
"""

# =============================================================================
# Finger exercise: Write an expression that computes the total
# number of goals scored by the losing teams in the quarter finals.
# =============================================================================

import pandas as pd
wwc = pd.read_csv('wwc2019_q-f.csv')

print((wwc[wwc['Round'] == 'Quarters']['L Goals'].sum()))