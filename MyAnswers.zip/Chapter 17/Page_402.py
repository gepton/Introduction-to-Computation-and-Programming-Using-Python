# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 19:44:59 2024

@author: gan
"""


# Finger exercise: Use the above formula to implement a function
# that calculates the probability of rolling exactly two 3’s in k rolls of a
# fair die. Use this function to plot the probability as k varies from 2 to
# 100.


import matplotlib.pyplot as plt
from scipy.special import comb
import random


def probability_two_threes(k):
  """
  Calculates the probability of rolling exactly two 3's in k rolls of a fair die.

  Args:
    k: Number of rolls (integer).

  Returns:
    Probability (float).
  """


def probability(k):
    multiplier_1 = comb(k, 2)
    multiplier_2 = (1/6)**2
    multiplier_3 = (5/6)**(k-2)
    return multiplier_1 * multiplier_2 * multiplier_3


values = range(2, 101)
prob_list = [probability(k) for k in values]

# Create and show the plot
plt.figure(figsize=(8, 6))
plt.plot(values, prob_list, label="Probability")
plt.xlabel("Number of Rolls (k)")
plt.ylabel("Probability of Two 3's")
plt.title("Probability of Rolling Two 3's in k Rolls")
plt.grid(True)
plt.legend()
plt.show()



def sim_insertions(num_indices, num_insertions):
    """Assumes num_indices and num_insertions are positive ints.
       Returns 1 if there is a collision; 0 otherwise"""
    choices = range(num_indices) #list of possible indices
    used = []
    for i in range(num_insertions):
        hash_val = random.choice(choices)
        if hash_val in used: #there is a collision
            return 1
        else:
            used.append(hash_val)
    return 0

def find_prob(num_indices, num_insertions, num_trials):
    collisions = 0
    for t in range(num_trials):
        collisions += sim_insertions(num_indices, num_insertions)
    return collisions/num_trials

print('Actual probability of a collision =', collision_prob(1000, 50))
print('Est. probability of a collision =', find_prob(1000, 50, 10000))
print('Actual probability of a collision =', collision_prob(1000, 200))
print('Est. probability of a collision =', find_prob(1000, 200, 10000))



def play_series(num_games, team_prob):
    numWon = 0
    for game in range(num_games):
        if random.random() <= team_prob:
            numWon += 1
    return (numWon > num_games//2)
  

def fraction_won(team_prob, num_series, series_len):
    won = 0
    for series in range(num_series):
        if play_series(series_len, team_prob):
            won += 1
    return won/float(num_series)

def sim_series(num_series):
    prob = 0.5
    fracsWon, probs = [], []
    while prob <= 1.0:
        fracsWon.append(fraction_won(prob, num_series, 7))
        probs.append(prob)
        prob += 0.01
    plt.axhline(0.95) #Draw line at 95%
    plt.plot(probs, fracsWon, 'k', linewidth = 5)
    plt.xlabel('Probability of Winning a Game')
    plt.ylabel('Probability of Winning a Series') 
    plt.title(str(num_series) + ' Seven-Game Series')

sim_series(400)


