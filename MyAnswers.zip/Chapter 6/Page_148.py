# -*- coding: utf-8 -*-
"""
Created on Fri Sep 22 19:18:04 2023

@author: gan
"""


def rec_funct(n):
    if n == 1:
        return n
    else:
        return 1/n + rec_funct(n-1)
    
print(rec_funct(20))