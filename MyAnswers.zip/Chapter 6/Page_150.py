# -*- coding: utf-8 -*-
"""
Created on Fri Sep 22 19:37:34 2023

@author: gan
"""

# Figure 6-3 on page 127      
def fib(n):
    """Assumes n int >= 0
    Returns Fibonacci of n"""
    count = 0
    if n == 2:
        count += 1
        print(count)
    if n == 0 or n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)



# def test_fib(n):
#     for i in range(n+1):
#         print('fib of', i, '=', fib(i))

# test_fib(6)


print(fib(5))