# -*- coding: utf-8 -*-
"""
Created on Fri Jan 12 19:39:16 2024

@author: gan
"""

"""Finger exercise: Use the tabular method to implement a dynamic
programming solution that meets the specification
def make_change(coin_vals, change):
coin_vals is a coin_list of positive ints and coin_vals[0] = 1
change is a positive int, return the minimum number of coins needed to have a
set of coins the values of which sum to change. Coins may
be used more than once. For example, make_change([1, 5,
8], 11) should return 3."""


# https://www.enjoyalgorithms.com/blog/minimum-coin-change


def minCoinChange(coin, K):
    if K == 0:
        return 0

    Change =  [K] * (K + 1)
    Change[0] = 0
    m = len(coin)
    
    for i in range (1, K + 1):
        for j in range(m):
             if coin[j] <= i:
                currCount = Change [i - coin[j]]
                if currCount != K and currCount + 1 < Change[i]:
                    Change[i] = currCount +1
                    
    if Change[K] == K:
        return -1
    else:
        return Change[K]


print(minCoinChange([1, 2, 3], 4))






# alternative solution

def make_change(coin_vals, change):
    coin_list = [0] + [change+1] * change
    for coin in coin_vals:
        for x in range(coin, change+1):
            coin_list[x] = min(coin_list[x], coin_list[x - coin] + 1)
    return coin_list[change] if coin_list[change] != change+1 else -1



#print(make_change([1, 5, 8], 11))


# https://reintech.io/blog/python-and-the-coin-change-problem
# https://www.geeksforgeeks.org/coin-change-dp-7/


#coin_list = [0] + [5] * 5


#dp = [[0 for j in range(5)] for i in range(3)]





