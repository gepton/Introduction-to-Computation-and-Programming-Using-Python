# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 19:07:30 2023

@author: gan
"""

data = input('enter your birthday in the form mm/dd/yyyy:  ')

print('You were born in the year ' + data[6:])

type(data)
