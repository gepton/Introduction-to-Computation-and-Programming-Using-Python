# -*- coding: utf-8 -*-
"""
Created on Tue Jul 25 19:41:31 2023

@author: gan
"""

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#Write a program that examines three variables—
#x, y, and z—and prints the largest odd number among them. If none
#of them are odd, it should print the smallest value of the three.
#You can attack this exercise in a number of ways. There are eight

num_x = int(input('How many times should I print the letter X ? '))
to_print = ''

while (num_x > 0):
    to_print = to_print + 'X'
    num_x = num_x - 1
print(to_print)