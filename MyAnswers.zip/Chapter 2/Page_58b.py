# -*- coding: utf-8 -*-
"""
Created on Wed Jul 26 19:13:40 2023

@author: gan
"""

#Write a program that asks the user to input 10
#integers, and then prints the largest odd number that was entered. If
#no odd number was entered, it should print a message to that effect.


counter = 0
odd_number = 0

while (counter < 10):
    data = int(input('Give next number {}:  '.format(counter)))
    if (data%2) != 0:
          odd_number = max(odd_number, data)
    counter += 1
print('No odd number was entered') if odd_number == 0 else print('Mαx odd number is: ', odd_number)
