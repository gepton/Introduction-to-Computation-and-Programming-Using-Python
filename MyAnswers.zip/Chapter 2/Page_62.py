# -*- coding: utf-8 -*-
"""
Created on Thu Jul 27 19:03:32 2023

@author: gan
"""

# Write a program that prints the sum of the prime
# numbers greater than 2 and less than 1000. Hint: you probably want
# to use a for loop that is a primality test nested inside a for loop that
# iterates over the odd integers between 3 and 999.

counter = 0
for i in range(3,1000,2):
    not_prime = True
    for j in range(3, 1000, 2):
        if i!=j and i%j == 0:
          not_prime = False
    if not_prime == True :
        counter = counter + i
print(counter)
          
            
# for i in range(3,500,2):
#     print(i)

# https://www.cuemath.com/numbers/prime-numbers-from-1-to-1000/
# https://el.wikipedia.org/wiki/%CE%A0%CF%81%CF%8E%CF%84%CE%BF%CF%82_%CE%B1%CF%81%CE%B9%CE%B8%CE%BC%CF%8C%CF%82