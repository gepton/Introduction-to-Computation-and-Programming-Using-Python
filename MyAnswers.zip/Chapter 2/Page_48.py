# -*- coding: utf-8 -*-
"""
Created on Mon Jul 17 19:16:37 2023

@author: gan
"""

x = 22
y = 8
z = 4

if x%2 == 0 and y%2 == 0 and z%2 == 0:
   value =  min(x, y,z)
elif x%2 != 0 or y%2 != 0 or z%2 != 0:
    value = max(x, y, z)
    
print(value)