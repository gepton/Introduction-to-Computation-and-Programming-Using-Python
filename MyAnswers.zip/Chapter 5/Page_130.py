# -*- coding: utf-8 -*-
"""
Created on Fri Sep 15 19:18:48 2023

@author: gan
"""

def f(L1, L2):
   """L1, L2 lists of same length of numbers
   returns the sum of raising each element in L1
   to the power of the element at the same index in L2
   For example, f([1,2], [2,3]) returns 9"""
   L3 = [] 

   for i in map(lambda x,y : x**y, L1, L2):
       L3 += [i,]
   return(sum(L3))
    
 
L1 = [1,2]
L2 = [2,3]    
print(f(L1, L2))    
