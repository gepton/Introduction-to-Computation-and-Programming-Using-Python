# -*- coding: utf-8 -*-
"""
Created on Mon Sep 11 19:17:40 2023

@author: gan
"""



lista = ()
lista = (2, 6, 8, 22, 44)
summary = 0
result = 0

for i in lista:
    summary = summary + i

result = summary/len(lista)
print(result)

