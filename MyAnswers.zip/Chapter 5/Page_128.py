# -*- coding: utf-8 -*-
"""
Created on Thu Sep 14 19:20:42 2023

@author: gan
"""


#generate a list of all prime numbers less than 100
print([x for x in range(2, 100) if all(x % y != 0 for y in
range(3, x))])


# Write a list comprehension that generates all
# non-primes between 2 and 100.
print([x for x in range(2, 100) if any(x % y == 0 for y in
range(2, x))])