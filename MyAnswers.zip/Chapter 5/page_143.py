# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 19:28:38 2023

@author: gan
"""


# Finger exercise: Using encoder and encrypt as models, implement
# the functions decoder and decrypt. Use them to decrypt the message
# 22*13*33*137*59*11*23*11*1*57*6*13*1*2*6*57*2*6*1*22*13*33*1
# 37*59*11*23*11*1*57*6*173*7*11
# which was encrypted using the opening of Don Quixote.


plain_text = 'no is no'

book = 'In a village of La Mancha, the name of which I have no desire to call to mind, there lived not long since one of those gentlemen that keep a lance in the lance-rack, an old buckler, a lean hack, and a greyhound for coursing.'

cipher_text = '22*13*33*137*59*11*23*11*1*57*6*13*1*2*6*57*2*6*1*22*13*33*1*37*59*11*23*11*1*57*6*173*7*11'

gen_code_keys = (lambda book, plain_text:({c: str(book.find(c)) for c in plain_text}))


encoder = (lambda code_keys, plain_text:''.join(['*' + code_keys[c] for c in plain_text])[1:])

#print(encoder(gen_code_keys(book,plain_text), plain_text))

encrypt = (lambda book, plain_text: encoder(gen_code_keys(book, plain_text), plain_text))

######################################################

gen_decode_keys = (lambda book, cipher_text: {s: book[int(s)] for s in cipher_text.split('*')})

#print(gen_decode_keys(book, cipher_text))


# added the if not s == '-1', in order to ignore if any -1's in the cipher_text
decoder = (lambda decode_keys,cipher_text:''.join([decode_keys[s] for s in cipher_text.split('*') if not s == '-1' ]))
#print(decoder(gen_decode_keys(book, cipher_text), cipher_text))


decrypt = (lambda book, cipher_text: decoder(gen_decode_keys(book, cipher_text), cipher_text))

print(decrypt(book, cipher_text))