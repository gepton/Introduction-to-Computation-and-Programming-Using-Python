# -*- coding: utf-8 -*-
"""
Created on Tue Sep 19 19:57:39 2023

@author: gan
"""

"""d a dict mapping letters to ints
   returns the value in d with the key that occurs first
   in the  alphabet. E.g., if d = {x = 11, b = 12}, get_min returns 12."""
   
   
def get_min(d):
    result = []
    for val in d.keys():
        result.append(val)
    return d[min(result)]

#d = {'a':1, 'b':2, 'c':3, 'd':4, 'e':5, 'f':6, 'g':7, 'h':8}
d = {'e':5, 'f':6, 'd':4, 'g':7,'h':8, 'a':1}

print(get_min(d))


print(d.items())
        


   
