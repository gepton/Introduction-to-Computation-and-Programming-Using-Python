# -*- coding: utf-8 -*-
"""
Created on Wed Oct  4 19:31:19 2023

@author: gan
"""

# =============================================================================
# Finger exercise: Implement a subclass of Person that meets the
# specification
# class Politician(Person):
# """ A politician is a person who can belong to a
# political party"""
# def __init__(self, name, party = None):
# """name and party are strings"""
# def get_party(self):
# """returns the party to which self belongs"""
# def might_agree(self, other):
# """returns True if self and other belong to the same
# part
# or at least one of then does not belong to a
# party"""
# =============================================================================


import datetime

class Person(object):
    
    def __init__(self, name):
        """Assumes name a string. Create a person"""
        self._name = name
        try:
            last_blank = name.rindex(' ')
            self._last_name = name[last_blank+1:]
        except:
            self._last_name = name
        self.birthday = None
        
    def get_name(self):
        """Returns self's full name"""
        return self._name
    
    def get_last_name(self):
        """Returns self's last name"""
        return self._last_name
    
    def set_birthday(self, birthdate):
        """Assumes birthdate is of type datetime.date
           Sets self's birthday to birthdate"""
        self._birthday = birthdate
        
    def get_age(self):
        """Returns self's current age in days"""
        if self._birthday == None:
            raise ValueError
        return (datetime.date.today() - self._birthday).days
    
    def __lt__(self, other):
        """Assume other a Person
           Returns True if self precedes other in alphabetical
           order, and False otherwise. Comparison is based on last
           names, but if these are the same full names are
           compared."""
        if self._last_name == other._last_name:
            return self._name < other._name
        return self._last_name < other._last_name
    
    def __str__(self):
        """Returns self's name"""
        return self._name
    

class Politician(Person):
    def __init__(self, name, party = None):
        super().__init__(name)
        self._party_id = party
    
    def set_party(self, party):
        self._party_id = party
    
    def get_party(self):
        return self._party_id
    
    def might_agree(self, other):
        if self._party_id == other._party_id or self._party_id == None or other._party_id == None:
            return True
    
    
p1 = Politician('John Wrag')
p1.set_party('PASOK')
print('name:', p1, 'party', p1.get_party())

p2 = Politician('Pit Ran')
p2.set_party('ND')
print('name:', p2, 'party', p2.get_party())

p3 = Politician('George Pan')
p3.set_party('ND')
print('name:', p3, 'party', p3.get_party())

print(p1.might_agree(p3))

        
        