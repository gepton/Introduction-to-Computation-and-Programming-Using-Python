# -*- coding: utf-8 -*-
"""
Created on Mon Sep  4 19:20:38 2023

@author: gan
"""

#Finger exercise: Using the algorithm of Figure 3-6, write a
#function that satisfies the specification
#def log(x, base, epsilon):
#"""Assumes x and epsilon int or float, base an int,
#x > 1, epsilon > 0 & power >= 1
#Returns float y such that base**y is within epsilon
#of x."""




# Figure 3-6
#Find lower bound on ans
def log(x, base, epsilon):
    """Assumes x and epsilon int or float, base an int,
x > 1, epsilon > 0 & power >= 1
Returns float y such that base**y is within epsilon
of x."""
    if x < 1 or epsilon < 0 or base < 1:
        return None
    lower_bound = 0
    while base**lower_bound < x:
      lower_bound += 1
      low = lower_bound - 1
      high = lower_bound + 1
#perform bisection search
    ans = (high + low)/2
    while abs(base**ans - x) >= epsilon:
      if base**ans < x:
        low = ans
      else:
        high = ans
    ans = (high + low)/2
    print(ans)
    return ans


epsilon = 0.01
x = 9
base = 3

y = log(x, base, epsilon)
print(y)