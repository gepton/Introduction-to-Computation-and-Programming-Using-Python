# -*- coding: utf-8 -*-
"""
Created on Wed Sep  6 19:38:30 2023

@author: gan
"""

t1 = (1, 'two', 3)
t2 = (t1, 3.25)
print(t2)
print((t1 + t2))
print((t1 + t2)[3])
print((t1 + t2)[2:5])
        
    