# -*- coding: utf-8 -*-
"""
Created on Wed Sep  6 19:29:50 2023

@author: gan
"""

result = lambda x, y: None if y == 0 else x / y

print(result(15,3))