# -*- coding: utf-8 -*-
"""
Created on Wed Aug 30 19:27:58 2023

@author: gan
"""

#Finger exercise: Use the find_root function in Figure 4-3 to print
#the sum of approximations to the square root of 25, the cube root of
#-8, and the fourth root of 16. Use 0.001 as epsilon.

# # Figure 4-3
def find_root(x, power, epsilon):
    #find interval containing answer
    if x < 0 and power%2 == 0:
        return None #Negative number has no even-powered roots
    low = min(-1, x)
    high = max(1, x)
    #use bisection search
    ans = (high + low)/2
    while abs(ans**power - x) >= epsilon:
        if ans**power < x:
            low = ans
        else:
            high = ans
        ans = (high + low)/2
    return ans

print(find_root(25, 2, 0.0001) + find_root(-8, 3, 0.0001) + find_root(16, 4, 0.0001))



# Finger exercise: Write a function is_in that accepts two strings as
# arguments and returns True if either string occurs anywhere in the
# other, and False otherwise. Hint: you might want to use the built-in
# str operator in.


def is_in(str1, str2):
    if str1 in str2 or str2 in str1:
        return True
    else:
        return False

#Finger exercise: Write a function to test is_in.

def test_is_in(str1, str2):
    counter = 0
    for i in str1:
            result = is_in(i, str2[counter])
            print(i, str2[counter], result)
            counter +=1

str1 = ('abcd', 'fask', 'qwerty', 'po', 'kj')
str2 = ('bc', 'qowp', 'qw', 'dfdpo', 'klshjd')
test_is_in(str1, str2)
    


