# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 19:18:33 2024

@author: gan
"""


# Finger exercise: Estimate the probability that a randomly chosen
# American is both male and weighs more than 197 pounds. Assume
# that 50% of the population is male, and that the weights of the male
# population are normally distributed with a mean of 210 pounds and a
# standard deviation of 30 pounds. (Hint: think about using the
# empirical rule.)
# The formula P(A|B, C) stands for the probability of A, given that
# both B and C hold. Assuming that B and C are independent of each
# other, the definition of a conditional probability and the
# multiplication rule for independent probabilities imply that P(A|B,C) = P(A,B,C)/P(B,C) 
# where the formula P(A, B, C) stands for the probability of all of A, B,
# and C being true.
# Similarly, P(A, B|C) stands for the probability of A and B, given
# C. Assuming that A and B are independent of each other P(A,B|C)=P(A|C)*P(B|C)



# Created code from Gemini

from scipy.stats import norm

# Define male population parameters
MALE_PERCENT = 0.5  # 50% of the population is male
MEAN_WEIGHT = 210  # Mean weight for males
STD_DEV = 30  # Standard deviation of weight for males

# Weight threshold
WEIGHT_THRESHOLD = 197

# Calculate probability using the empirical rule (68-95-99.7 rule)
# 68% of the population falls within 1 standard deviation of the mean
# We only care about the right tail (> 197 pounds) so calculate the area from threshold to mean
one_std_dev_above = norm.cdf(MEAN_WEIGHT + STD_DEV, MEAN_WEIGHT, STD_DEV)
probability_above_threshold = 1 - one_std_dev_above

# Since gender and weight are assumed independent
# Probability of being male and above threshold is product of individual probabilities
final_probability = MALE_PERCENT * probability_above_threshold

print(f"Estimated probability: {final_probability:.4f}")



# This code uses the scipy.stats library's norm function to work with the normal distribution.

# Explanation:

# We define constants for male population percentage, mean weight, standard deviation, and weight threshold.
# We use the empirical rule to estimate the probability of someone being above the weight threshold. 
# The norm.cdf function calculates the cumulative distribution function (CDF) for the normal distribution. 
# We subtract the CDF value at one standard deviation above the mean from 1 to get the probability in the upper tail (> 197 pounds).
# Since gender and weight are assumed independent, we multiply the probability of being male (50%) with the probability of being above the weight threshold to get the final probability.
# The code then prints the estimated probability.
# This approach provides an estimate without directly calculating the entire distribution, making it more efficient.