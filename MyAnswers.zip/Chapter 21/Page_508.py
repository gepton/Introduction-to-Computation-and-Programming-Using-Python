# -*- coding: utf-8 -*-
"""
Created on Thu Apr 18 19:35:16 2024

@author: gan
"""

# Finger exercise: You are wandering through a forest and see a
# field of delicious-looking mushrooms. You fill your basket with them,
# and head home prepared to cook them up and serve them to your
# husband. Before you cook them, however, he demands that you
# consult a book about local mushroom species to check whether they
# are poisonous. The book says that 80% of the mushrooms in the local
# forest are poisonous. However, you compare your mushrooms to the
# ones pictured in the book, and decide that you are 95% certain that
# your mushrooms are safe. How comfortable should you be about
# serving them to your husband (assuming that you would rather not
# become a widow)?




# P(poisonous) = 0.8
# P(safe | poisonous) = 0.95
# P(poisonous | safe) = ?  

#  P(poisonous | safe) = P(poisonous) * P(safe | poisonous) / P(safe)
P1 = (0.8 * 0.95) / 0.96

# P(safe) = P(safe | poisonous) * P(poisonous) + P(safe | not poisonous) * (1 - P(poisonous))
P2 = 0.95 * 0.8 + 1 * 0.2   #  = 0.96





