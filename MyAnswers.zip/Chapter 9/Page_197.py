# -*- coding: utf-8 -*-
"""
Created on Fri Sep 29 19:38:41 2023

@author: gan
"""


# Finger exercise: Implement a function that satisfies the
# specification
# def find_an_even(L):
# """Assumes L is a list of integers
# Returns the first even number in L
# Raises ValueError if L does not contain an even
# number"""



def find_an_even(L):
   """Assumes L is a list of integers
   Returns the first even number in L
   Raises ValueError if L does not contain an even
   number"""

# put all even numbers in a list
   even_list = [num for num in L if num % 2 == 0]   
   
   if not len(even_list):
        raise ValueError ('L does not contain an even number')
   else:
       return even_list[0]

      
    
L = [1,5,7,9,8,35,66]

print(find_an_even(L))
    