# -*- coding: utf-8 -*-
"""
Created on Fri Feb 23 19:33:49 2024

@author: gan
"""


# Finger exercise: A “big 6” bet pays even money if a 6 is rolled
# before a 7. Assuming 30 $5 bets per hour, write a Monte Carlo
# simulation that estimates the cost per hour and the standard
# deviation of that cost of playing “big 6” bets.


import random

# # Figure 18-1 on page 396
def roll_die():
    return random.choice([1,2,3,4,5,6])



class Craps_game(object):
    def __init__(self):
        self.wins, self.losses = 0, 0
        

    def play_hand(self):
        first_roll = roll_die() + roll_die()
        while first_roll != 6 and first_roll != 7:
          first_roll = roll_die() + roll_die()
        if first_roll == 6:
          self.wins += 5  # Win $5
        else:
          self.losses += 5  # Lose $5       
                
    def pass_results(self):
        return (self.wins, self.losses)
    
    def return_losses(self):
        return (self.losses)

     
def craps_sim(hands_per_game, num_games):
    """Assumes hands_per_game and num_games are ints > 0
       Play num_games games of hands_per_game hands; print results"""
    costs = []

    #Play num_games games
    for t in range(num_games):
        c = Craps_game()
        for i in range(hands_per_game):
            c.play_hand()
        costs.append(c.return_losses())
        
# Calculate and display the mean (average cost)
    average_cost = sum(costs) / len(costs)
    print(f"Average cost per hour: ${average_cost:.2f}")

 # Calculate and display the standard deviation of the cost
    standard_deviation = sum((cost - average_cost)**2 for cost in costs) / (len(costs) - 1)
    standard_deviation = standard_deviation**0.5
    print(f"Standard deviation of cost: ${standard_deviation:.2f}")        

        
craps_sim(10000, 100)
        

