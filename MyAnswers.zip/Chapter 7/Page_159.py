# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 19:49:02 2023

@author: gan
"""

import circle
pi = 3
print(pi)
print(circle.pi)
print(circle.area(3))
print(circle.circumference(3))
print(circle.sphere_surface(3))