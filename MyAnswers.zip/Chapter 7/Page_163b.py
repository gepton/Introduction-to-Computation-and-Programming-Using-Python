# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 19:56:37 2023

@author: gan
"""

# Finger exercise: Since 1958, Canadian Thanksgiving has occurred
# on the second Monday in October. Write a function that takes a year
# (>1957) as a parameter, and returns the number of days between
# Canadian Thanksgiving and Christmas.

import calendar as cal


def shopping_days(year):
   month = cal.monthcalendar(year, 10)
   if month[0][cal.MONDAY] != 0:
      thanksgiving = month[1][cal.MONDAY]
   else:
      thanksgiving = month[2][cal.MONDAY]
   # Find the max date of the month October
   max_date = max(max(month))
   # Find the max date of the month November
   nov_month = max(max(cal.monthcalendar(year, 11)))
   return max_date - thanksgiving + 25 + nov_month

print('The number of days between U.S. Thanksgiving and Christmas is: ', shopping_days(1980), 'days')
