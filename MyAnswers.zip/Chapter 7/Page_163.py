# -*- coding: utf-8 -*-
"""
Created on Tue Sep 26 19:44:13 2023

@author: gan
"""

# Finger exercise: Write a function that meets the specification
# def shopping_days(year):
# """year a number >= 1941
# returns the number of days between U.S. Thanksgiving
# and
# Christmas in year"""

import calendar as cal


def shopping_days(year):
   month = cal.monthcalendar(year, 11)
   #print(month)
   if month[0][cal.THURSDAY] != 0:
      thanksgiving = month[3][cal.THURSDAY]
   else:
      thanksgiving = month[4][cal.THURSDAY]
   # Find the max date of the month
   max_date = max(max(month))
   return max_date - thanksgiving + 25

print('The number of days between U.S. Thanksgiving and Christmas is: ', shopping_days(2021), 'days')
