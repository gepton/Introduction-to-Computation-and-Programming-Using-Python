# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 19:03:02 2023

@author: gan
"""

# Finger exercise: Write a program that first stores the first ten
# numbers in the Fibonnaci sequence to a file named fib_file. Each
# number should be on a separate line in the file. The program should
# then read the numbers from the file and print them.

    
def fib(n):
    """Assumes n int >= 0
    Returns Fibonacci of n"""
    if n == 0 or n == 1:
        return 1
    else:
        return fib(n-1) + fib(n-2)

def store():
    store = open('fib_file', 'w')
    for i in range(11):
        store.write(str(fib(i)) + '\n')
    store.close()
    
def read():
    with open('fib_file', 'r') as read_file:
        for line in read_file:
            print(line[:-1])

store()
read()